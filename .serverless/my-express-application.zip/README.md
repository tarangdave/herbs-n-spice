# herbs-n-spice

### Installation
+ npm install --save express serverless-http
+ npm install --save-dev serverless-offline
+ npm install -g serverless
+ npm install --save-dev serverless-dynamodb-local
+ sls dynamodb install
+ sls offline start
+ serverless config credentials --provider aws --key "accesskey" --secret "secretkey"